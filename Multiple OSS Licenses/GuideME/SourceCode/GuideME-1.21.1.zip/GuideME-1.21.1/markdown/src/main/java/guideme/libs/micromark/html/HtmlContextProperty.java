package guideme.libs.micromark.html;

/**
 * Attach arbitrary data to {@link HtmlContext}. For use by {@linkplain HtmlExtension extensions}.
 *
 * @param <T> The type of data associated with this property.
 */
@SuppressWarnings("unused")
public final class HtmlContextProperty<T> {
}
